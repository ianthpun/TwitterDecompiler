/*Ian Pun
Student number : 301167944
itpun@sfu.ca
CMPT 300 D100
Instructor: Brian Booth
TA: Scott Kristjanson
*/

#include <string.h>
#include <stdio.h>
#include <time.h>
#include "memwatch.h"

char * CurrTime(time_t ltime);
void ProcessCleanup(int ProcessCount, int ProcessArr[]);
int AlgoCheck(char* algo);




